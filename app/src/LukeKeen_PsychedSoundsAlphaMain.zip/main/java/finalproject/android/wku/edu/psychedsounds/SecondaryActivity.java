package finalproject.android.wku.edu.psychedsounds;
//LUKE KEEN
//4/20/2018
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

//currently an unused activity, but not for long.
public class SecondaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);

        //All I do for this activity is setup the same toolbar as before but without any actions and an up button.
        Toolbar myToolBar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolBar);

        ActionBar ab = getSupportActionBar();
        //this is where the up button is displayed.
        ab.setDisplayHomeAsUpEnabled(true);
    }
}
